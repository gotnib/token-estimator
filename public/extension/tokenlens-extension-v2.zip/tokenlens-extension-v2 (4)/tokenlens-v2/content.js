(() => {
  'use strict';
  if (document.getElementById('tokenlens-root')) return;
  // ── Site adapters ─────────────────────────────────────────────────────
  const SITE_ADAPTERS = [
    {
      test: () => location.hostname.includes('chatgpt.com') || location.hostname.includes('openai.com'),
      getPrompt: () => {
        const el = document.querySelector('#prompt-textarea, div[contenteditable="true"][data-lexical-editor]');
        return el ? (el.value ?? el.innerText ?? '') : '';
      },
      setPrompt: (text) => {
        const el = document.querySelector('#prompt-textarea, div[contenteditable="true"][data-lexical-editor]');
        if (!el) return false;
        el.focus();
        if (el.tagName === 'TEXTAREA') {
          const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
          nativeSetter.set.call(el, text);
          el.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          document.execCommand('selectAll', false, null);
          document.execCommand('insertText', false, text);
        }
        return true;
      },
      getPlatform: () => 'ChatGPT'
    },
    {
      test: () => location.hostname.includes('claude.ai'),
      getPrompt: () => {
        const el = document.querySelector('div[contenteditable="true"].ProseMirror, div.ProseMirror');
        return el ? (el.innerText ?? '') : '';
      },
      setPrompt: (text) => {
        const el = document.querySelector('div[contenteditable="true"].ProseMirror, div.ProseMirror');
        if (!el) return false;
        el.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, text);
        return true;
      },
      getPlatform: () => 'Claude'
    },
    {
      test: () => location.hostname.includes('gemini.google.com'),
      getPrompt: () => {
        const el = document.querySelector('div.ql-editor, rich-textarea .ql-editor');
        return el ? (el.innerText ?? '') : '';
      },
      setPrompt: (text) => {
        const el = document.querySelector('div.ql-editor, rich-textarea .ql-editor');
        if (!el) return false;
        el.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, text);
        return true;
      },
      getPlatform: () => 'Gemini'
    },
    {
      test: () => location.hostname.includes('copilot.microsoft.com'),
      getPrompt: () => {
        const el = document.querySelector('textarea#userInput, [data-testid="composer-input"]');
        return el ? (el.value ?? el.innerText ?? '') : '';
      },
      setPrompt: (text) => {
        const el = document.querySelector('textarea#userInput, [data-testid="composer-input"]');
        if (!el) return false;
        el.focus();
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
        nativeSetter.set.call(el, text);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      },
      getPlatform: () => 'Copilot'
    },
    {
      test: () => location.hostname.includes('grok.com'),
      getPrompt: () => {
        const el = document.querySelector('textarea, div[contenteditable="true"]');
        return el ? (el.value ?? el.innerText ?? '') : '';
      },
      setPrompt: (text) => {
        const el = document.querySelector('textarea, div[contenteditable="true"]');
        if (!el) return false;
        el.focus();
        if (el.tagName === 'TEXTAREA') {
          const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
          nativeSetter.set.call(el, text);
          el.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          document.execCommand('selectAll', false, null);
          document.execCommand('insertText', false, text);
        }
        return true;
      },
      getPlatform: () => 'Grok'
    },
    {
      test: () => location.hostname.includes('poe.com'),
      getPrompt: () => {
        const el = document.querySelector('textarea[class*="GrowingTextArea"], textarea[placeholder]');
        return el ? el.value ?? '' : '';
      },
      setPrompt: (text) => {
        const el = document.querySelector('textarea[class*="GrowingTextArea"], textarea[placeholder]');
        if (!el) return false;
        el.focus();
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
        nativeSetter.set.call(el, text);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      },
      getPlatform: () => 'Poe'
    },
    {
      test: () => location.hostname.includes('perplexity.ai'),
      getPrompt: () => {
        const el = document.querySelector('textarea[placeholder], div[contenteditable="true"]');
        return el ? (el.value ?? el.innerText ?? '') : '';
      },
      setPrompt: (text) => {
        const el = document.querySelector('textarea[placeholder], div[contenteditable="true"]');
        if (!el) return false;
        el.focus();
        if (el.tagName === 'TEXTAREA') {
          const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
          nativeSetter.set.call(el, text);
          el.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          document.execCommand('selectAll', false, null);
          document.execCommand('insertText', false, text);
        }
        return true;
      },
      getPlatform: () => 'Perplexity'
    },
    {
      test: () => location.hostname.includes('runable.com'),
      getPrompt: () => {
        const RUNABLE_SELECTORS = [
          'textarea[data-testid="chat-input"]','textarea[placeholder*="What"]','textarea[placeholder*="needs"]',
          'textarea[placeholder*="message"]','textarea[placeholder*="Ask"]',
          'div[contenteditable="true"][class*="input"]','div[contenteditable="true"][class*="chat"]',
          'div[contenteditable="true"][class*="prompt"]','textarea'
        ];
        for (const sel of RUNABLE_SELECTORS) {
          const el = document.querySelector(sel);
          if (el) return el.value ?? el.innerText ?? '';
        }
        return '';
      },
      setPrompt: (text) => {
        const RUNABLE_SELECTORS = [
          'textarea[data-testid="chat-input"]','textarea[placeholder*="What"]','textarea[placeholder*="needs"]',
          'textarea[placeholder*="message"]','textarea[placeholder*="Ask"]',
          'div[contenteditable="true"][class*="input"]','div[contenteditable="true"][class*="chat"]',
          'div[contenteditable="true"][class*="prompt"]','textarea'
        ];
        let el = null;
        for (const sel of RUNABLE_SELECTORS) { el = document.querySelector(sel); if (el) break; }
        if (!el) return false;
        el.focus();
        if (el.tagName === 'TEXTAREA') {
          const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
          nativeSetter.set.call(el, text);
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
          document.execCommand('selectAll', false, null);
          document.execCommand('insertText', false, text);
        }
        return true;
      },
      getPlatform: () => 'Runable'
    }
  ];
  const adapter = SITE_ADAPTERS.find(a => a.test()) ?? null;
  const canInject = !!(adapter && adapter.setPrompt);

  // ── Detect current platform ───────────────────────────────────────────
  function getCurrentPlatform() {
    if (adapter && adapter.getPlatform) return adapter.getPlatform();
    const host = location.hostname.replace('www.', '');
    if (host.includes('claude.ai')) return 'Claude';
    if (host.includes('chatgpt.com') || host.includes('openai.com')) return 'ChatGPT';
    if (host.includes('gemini.google.com')) return 'Gemini';
    if (host.includes('perplexity.ai')) return 'Perplexity';
    if (host.includes('mistral.ai')) return 'Mistral';
    if (host.includes('groq.com')) return 'Groq';
    return 'Unknown';
  }

  function debounce(fn, ms) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  }

  // ── Code detection ────────────────────────────────────────────────────
  const CODE_PATTERNS = [
    /```[\s\S]{10,}/,
    /^\s*(function|def |class |const |let |var |import |export |public |private )/m,
    /^\s*(if|for|while|switch)\s*\(/m,
    /(=>|->)\s*[{(]/,
    /\b(return|await|async|yield|throw|try|catch)\b/,
    /#include\s*[<"]/,
    /\b(SELECT|INSERT|UPDATE|DELETE|FROM|WHERE)\b/i,
    /<[a-zA-Z][^>]*>[\s\S]*<\/[a-zA-Z]+>/,
    /^\s*@\w+\s*[\n\r]/m,
    /[{};]\s*\n.*[{};]/s,
  ];
  const CODE_THRESHOLD = 2;
  function detectCode(text) {
    if (!text || text.length < 30) return false;
    let matches = 0;
    for (const pattern of CODE_PATTERNS) {
      if (pattern.test(text)) { matches++; if (matches >= CODE_THRESHOLD) return true; }
    }
    return false;
  }

  // ── Session tracker ───────────────────────────────────────────────────
  const session = {
    userTokens: 0, assistantTokens: 0, messages: 0,
    userMessages: 0, assistantMessages: 0,
    turns: [], seenKeys: new Set(),
    repeatedTokens: 0, repeatedBlocks: 0,
    textFingerprints: new Map()
  };
  function estimateTokens(text) { return Math.ceil((text || '').length / 4); }
  function normalizeMessageText(text) { return (text || '').replace(/\s+/g, ' ').trim(); }
  function fingerprint(text) {
    const normalized = normalizeMessageText(text).slice(0, 500);
    let hash = 0;
    for (let i = 0; i < normalized.length; i++) hash = ((hash << 5) - hash + normalized.charCodeAt(i)) | 0;
    return String(hash) + ':' + normalized.length;
  }
  function getHostKey() {
    const host = location.hostname.replace('www.', '');
    const keys = ['chatgpt.com','openai.com','claude.ai','gemini.google.com','copilot.microsoft.com','grok.com','poe.com','perplexity.ai','runable.com'];
    return keys.find(k => host.includes(k)) ?? null;
  }
  const MESSAGE_SELECTORS = {
    'chatgpt.com':           { user: '[data-message-author-role="user"]', assistant: '[data-message-author-role="assistant"]' },
    'openai.com':            { user: '[data-message-author-role="user"]', assistant: '[data-message-author-role="assistant"]' },
    'claude.ai':             { user: '[data-testid="user-message"], .font-user-message', assistant: '[data-testid="assistant-message"], .font-claude-message, [data-is-streaming]' },
    'gemini.google.com':     { user: '.user-query-bubble-with-background', assistant: '.model-response-text, message-content' },
    'copilot.microsoft.com': { user: '[data-testid="user-message"]', assistant: '[data-testid="bot-message"], [data-content="ai-message"]' },
    'grok.com':              { user: '[class*="UserMessage"]', assistant: '[class*="AssistantMessage"], [class*="Response"]' },
    'poe.com':               { user: '[class*="Message_humanMessageBubble"]', assistant: '[class*="Message_botMessageBubble"]' },
    'perplexity.ai':         { user: '[data-testid="user-message-content"]', assistant: '[data-testid="answer"], [class*="Answer"]' },
    'runable.com':           { user: '[class*="UserMessage"], [class*="user-message"], [data-role="user"]', assistant: '[class*="AssistantMessage"], [class*="assistant-message"], [data-role="assistant"]' }
  };

  function startSessionTracker() {
    const hostKey = getHostKey();
    const selectors = hostKey ? MESSAGE_SELECTORS[hostKey] : null;
    if (!selectors) return;
    function scanRole(role, selector) {
      if (!selector) return;
      document.querySelectorAll(selector).forEach((el) => {
        const text = normalizeMessageText(el.innerText || el.textContent || '');
        if (!text || text.length < 2) return;
        const key = role + ':' + fingerprint(text);
        if (session.seenKeys.has(key)) return;
        session.seenKeys.add(key);
        const tokens = estimateTokens(text);
        const shortText = text.length > 140 ? text.slice(0, 140) + '…' : text;
        session.messages += 1;
        if (role === 'user') { session.userMessages += 1; session.userTokens += tokens; }
        else { session.assistantMessages += 1; session.assistantTokens += tokens; }
        const fp = fingerprint(text.slice(0, 1200));
        const previousCount = session.textFingerprints.get(fp) || 0;
        session.textFingerprints.set(fp, previousCount + 1);
        if (previousCount > 0) { session.repeatedTokens += tokens; session.repeatedBlocks += 1; }
        session.turns.push({ role, tokens, text: shortText, repeated: previousCount > 0, at: Date.now() });
        if (session.turns.length > 40) session.turns.shift();
        updateSessionUI();
        renderPowerUserPanel();
      });
    }
    function scanMessages() { scanRole('user', selectors.user); scanRole('assistant', selectors.assistant); }
    scanMessages();
    const observer = new MutationObserver(debounce(scanMessages, 500));
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function getSessionTotals() {
    const totalTokens = session.userTokens + session.assistantTokens;
    const userShare = totalTokens ? Math.round((session.userTokens / totalTokens) * 100) : 0;
    return { totalTokens, estimatedNextContext: totalTokens, userShare, assistantShare: totalTokens ? 100 - userShare : 0, repeatedShare: totalTokens ? Math.round((session.repeatedTokens / totalTokens) * 100) : 0 };
  }

  function getConversationHealth() {
    const totals = getSessionTotals();
    const total = totals.totalTokens;
    const repeated = totals.repeatedShare;
    const assistantHeavy = totals.assistantShare > 72 && total > 2000;
    const fastGrowth = session.turns.slice(-3).reduce((sum, t) => sum + t.tokens, 0) > 6000;
    if (!total) return { label: 'Ready', tone: 'ready', detail: 'Open a prompt to begin.', suggestion: 'Enable auto detect for the smoothest workflow.' };
    if (repeated >= 28) return { label: 'Repetitive', tone: 'warn', detail: 'Repeated context is building up.', suggestion: 'Consider saving reusable instructions as a memory snippet.' };
    if (total >= 42000) return { label: 'Heavy', tone: 'danger', detail: 'This conversation is carrying a lot of visible context.', suggestion: 'A recap or fresh thread may keep results cleaner.' };
    if (fastGrowth) return { label: 'Growing Fast', tone: 'warn', detail: 'Recent turns added a large amount of context.', suggestion: 'Compress logs or long pasted sections before continuing.' };
    if (assistantHeavy) return { label: 'Growing', tone: 'warn', detail: 'Assistant replies are driving most context growth.', suggestion: 'Ask for shorter answers when you need to preserve context.' };
    if (total >= 16000) return { label: 'Healthy', tone: 'good', detail: 'Context is still manageable.', suggestion: 'Keep repeated instructions short and consistent.' };
    return { label: 'Excellent', tone: 'good', detail: 'Conversation context looks clean.', suggestion: 'Keep using concise instructions to maintain quality.' };
  }

  function getPassiveInsight() {
    const totals = getSessionTotals();
    const health = getConversationHealth();
    const currentInputTokens = estimateTokens(textarea?.value || '');
    if (currentInputTokens > 3000) return { title: 'Large input detected', body: 'Consider compressing logs or background context before sending.' };
    if (session.repeatedBlocks > 0) return { title: 'Repeated instructions detected', body: 'Reusable instructions may work better as a saved memory snippet.' };
    if (totals.assistantShare > 72 && totals.totalTokens > 2000) return { title: 'Assistant replies are adding most context', body: 'Ask for shorter responses to slow context growth.' };
    if (health.label === 'Heavy' || health.label === 'Growing Fast') return { title: 'Conversation recap may help', body: 'A concise recap can reduce clutter before continuing.' };
    return null;
  }

  function updateSessionUI() {
    const totals = getSessionTotals();
    const health = getConversationHealth();
    const el = document.getElementById('tl-session-tokens');
    if (el) el.textContent = fmt(totals.totalTokens);
    const msgs = document.getElementById('tl-session-msgs');
    if (msgs) msgs.textContent = session.messages + ' msg' + (session.messages !== 1 ? 's' : '');
    const compact = document.getElementById('tl-health-compact');
    if (compact) { compact.className = 'tl-health-pill ' + health.tone; compact.textContent = health.label + ' · ' + fmt(totals.totalTokens) + ' context'; }
    const insight = document.getElementById('tl-passive-insight');
    if (insight) {
      const item = getPassiveInsight();
      if (item) {
        insight.innerHTML = '<button id="tl-insight-dismiss" type="button">×</button><strong>' + escapeHTML(item.title) + '</strong><span>' + escapeHTML(item.body) + '</span>';
        insight.style.display = 'block';
        const dismiss = document.getElementById('tl-insight-dismiss');
        if (dismiss) dismiss.addEventListener('click', () => { insight.style.display = 'none'; });
      }
    }
    // Update save button token count
    const saveBtn = document.getElementById('tl-save-chat-btn');
    if (saveBtn && totals.totalTokens > 0) {
      saveBtn.title = 'Save chat to Blueprint Library (' + totals.totalTokens.toLocaleString() + ' tokens)';
    }
  }

  function renderPowerUserPanel() {
    const panel = document.getElementById('tl-power-panel');
    if (!panel) return;
    const totals = getSessionTotals();
    const health = getConversationHealth();
    const contextPct = Math.min(100, Math.round((totals.estimatedNextContext / 128000) * 100));
    const recentTurns = session.turns.slice(-10).reverse();
    const timelineTurns = session.turns.slice(-16);
    const timelineHTML = timelineTurns.length
      ? timelineTurns.map((turn) => {
          const height = Math.max(12, Math.min(72, Math.round((turn.tokens / Math.max(1, Math.max(...timelineTurns.map(t => t.tokens)))) * 72)));
          return '<div class="tl-timeline-bar ' + turn.role + (turn.repeated ? ' repeated' : '') + '" style="height:' + height + 'px" title="' + (turn.role === 'user' ? 'You' : 'AI') + ' · ' + turn.tokens + ' tokens"></div>';
        }).join('')
      : '<div class="tl-timeline-empty">Usage timeline appears as the conversation grows.</div>';
    const turnsHTML = recentTurns.length
      ? recentTurns.map(turn =>
          '<details class="tl-turn-row ' + (turn.repeated ? 'repeated' : '') + '">' +
            '<summary><span class="tl-turn-role">' + (turn.role === 'user' ? 'You' : 'AI') + '</span><span class="tl-turn-tokens">' + turn.tokens.toLocaleString() + ' tokens</span>' + (turn.repeated ? '<span class="tl-turn-flag">cache candidate</span>' : '') + '</summary>' +
            '<div class="tl-turn-text">' + escapeHTML(turn.text) + '</div>' +
          '</details>'
        ).join('')
      : '<div class="tl-power-empty">Start a conversation and TokenLens will estimate the visible chat usage here.</div>';
    panel.innerHTML =
      '<div class="tl-power-note elegant"><strong>Passive analysis only.</strong> TokenLens observes visible chat content. It does not intercept, resend, or claim exact provider billing data.</div>' +
      '<div class="tl-health-card ' + health.tone + '"><div><span class="tl-power-label">CONVERSATION HEALTH</span><strong>' + health.label + '</strong><p>' + escapeHTML(health.detail) + '</p></div><div class="tl-health-action">' + escapeHTML(health.suggestion) + '</div></div>' +
      '<div class="tl-context-card timeline-card"><div class="tl-context-head"><span>Context timeline</span><strong>' + contextPct + '% of 128k</strong></div><div class="tl-timeline">' + timelineHTML + '</div><div class="tl-context-split"><span>User ' + totals.userShare + '%</span><span>Assistant ' + totals.assistantShare + '%</span><span>Repeated ' + totals.repeatedShare + '%</span></div></div>' +
      '<div class="tl-power-grid compact">' +
        '<div class="tl-power-card"><span class="tl-power-label">TOTAL CHAT</span><strong>' + totals.totalTokens.toLocaleString() + '</strong><small>' + session.messages + ' visible messages</small></div>' +
        '<div class="tl-power-card"><span class="tl-power-label">YOUR INPUT</span><strong>' + session.userTokens.toLocaleString() + '</strong><small>' + session.userMessages + ' messages</small></div>' +
        '<div class="tl-power-card"><span class="tl-power-label">AI OUTPUT</span><strong>' + session.assistantTokens.toLocaleString() + '</strong><small>' + session.assistantMessages + ' messages</small></div>' +
        '<div class="tl-power-card accent"><span class="tl-power-label">REPEATED</span><strong>' + session.repeatedTokens.toLocaleString() + '</strong><small>' + session.repeatedBlocks + ' candidates</small></div>' +
      '</div>' +
      '<div class="tl-memory-card"><div class="tl-memory-head"><div><span class="tl-power-label">LIGHTWEIGHT MEMORY</span><strong>Reusable snippets</strong></div><button id="tl-save-snippet" type="button">Save input</button></div><p>Save short reusable instructions without turning the widget into a prompt library.</p><div id="tl-memory-list" class="tl-memory-list"></div></div>' +
      '<div class="tl-cache-card elegant"><div><span class="tl-power-label">REPEATED CONTEXT CANDIDATES</span><strong>' + session.repeatedTokens.toLocaleString() + ' tokens</strong></div><p>Repeated visible blocks may benefit from provider caching, but TokenLens cannot verify cache reads without direct API usage data.</p></div>' +
      '<div class="tl-turn-list"><div class="tl-turn-list-title">Recent visible turns</div>' + turnsHTML + '</div>';
    wireMemoryControls();
  }

  let memorySnippets = [];
  function loadMemorySnippets() {
    chrome.storage.local.get(['tokenlens_memory_snippets'], (data) => {
      memorySnippets = Array.isArray(data.tokenlens_memory_snippets) ? data.tokenlens_memory_snippets.slice(0, 6) : [];
      renderMemoryList();
    });
  }
  function saveMemorySnippets() { chrome.storage.local.set({ tokenlens_memory_snippets: memorySnippets.slice(0, 6) }); }
  function wireMemoryControls() {
    const saveBtn = document.getElementById('tl-save-snippet');
    if (saveBtn) {
      saveBtn.addEventListener('click', () => {
        const text = normalizeMessageText(textarea.value).slice(0, 500);
        if (!text) return;
        memorySnippets = [{ text, at: Date.now() }, ...memorySnippets.filter(s => s.text !== text)].slice(0, 6);
        saveMemorySnippets();
        renderMemoryList();
      });
    }
    renderMemoryList();
  }
  function renderMemoryList() {
    const list = document.getElementById('tl-memory-list');
    if (!list) return;
    if (!memorySnippets.length) { list.innerHTML = '<div class="tl-memory-empty">No snippets yet. Save short instructions you reuse often.</div>'; return; }
    list.innerHTML = memorySnippets.map((item, idx) =>
      '<div class="tl-memory-item"><button class="tl-memory-use" data-idx="' + idx + '" type="button">Use</button><span>' + escapeHTML(item.text.length > 96 ? item.text.slice(0, 96) + '…' : item.text) + '</span><button class="tl-memory-remove" data-idx="' + idx + '" type="button">×</button></div>'
    ).join('');
    list.querySelectorAll('.tl-memory-use').forEach(btn => btn.addEventListener('click', () => {
      const item = memorySnippets[Number(btn.dataset.idx)];
      if (!item) return;
      textarea.value = textarea.value ? textarea.value + '\n\n' + item.text : item.text;
      updateBadge(textarea.value); autoDetectMode(textarea.value);
    }));
    list.querySelectorAll('.tl-memory-remove').forEach(btn => btn.addEventListener('click', () => {
      memorySnippets.splice(Number(btn.dataset.idx), 1); saveMemorySnippets(); renderMemoryList();
    }));
  }

  function escapeHTML(value) {
    return String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
  }

  // ── Build chat log text from session turns ────────────────────────────
  function buildChatLogText() {
    // First try reading directly from the DOM for higher-fidelity capture
    const hostKey = getHostKey();
    const selectors = hostKey ? MESSAGE_SELECTORS[hostKey] : null;
    let lines = [];
    if (selectors) {
      // Interleave user + assistant messages in DOM order
      const allMessages = [];
      document.querySelectorAll(selectors.user).forEach(el => {
        const text = (el.innerText || el.textContent || '').trim();
        if (text) allMessages.push({ role: 'user', text, top: el.getBoundingClientRect().top });
      });
      document.querySelectorAll(selectors.assistant).forEach(el => {
        const text = (el.innerText || el.textContent || '').trim();
        if (text) allMessages.push({ role: 'assistant', text, top: el.getBoundingClientRect().top });
      });
      // Sort by vertical position in the page
      allMessages.sort((a, b) => a.top - b.top);
      lines = allMessages.map(m => (m.role === 'user' ? 'User: ' : 'Assistant: ') + m.text);
    }
    // Fall back to session.turns if DOM read produced nothing
    if (!lines.length && session.turns.length) {
      lines = session.turns.map(t => (t.role === 'user' ? 'User: ' : 'Assistant: ') + t.text);
    }
    return lines.join('\n\n');
  }

  // ── Save Chat as Blueprint ────────────────────────────────────────────
  let saveChatInProgress = false;

  async function saveChatAsBlueprint() {
    if (saveChatInProgress) return;
    if (!authToken) {
      showSaveChatState('error', 'Sign in to save chats.');
      return;
    }
    const totals = getSessionTotals();
    if (totals.totalTokens === 0 && session.turns.length === 0) {
      showSaveChatState('error', 'No chat to save yet.');
      return;
    }
    saveChatInProgress = true;
    showSaveChatState('loading', '');
    try {
      const rawText = buildChatLogText();
      if (!rawText || rawText.trim().length < 20) {
        showSaveChatState('error', 'Not enough chat content to save.');
        saveChatInProgress = false;
        return;
      }
      const platform = getCurrentPlatform();
      const res = await fetch('https://tokenlens.live/api/blueprint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + authToken },
        body: JSON.stringify({
          action:      'save',
          raw_text:    rawText,
          platform:    platform,
          token_count: totals.totalTokens,
        })
      });
      if (res.status === 401) {
        chrome.storage.local.remove(['tokenlens_token', 'tokenlens_token_at']);
        authToken = null;
        updateAuthUI();
        showSaveChatState('error', 'Session expired. Sign in again.');
        saveChatInProgress = false;
        return;
      }
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Save failed');
      showSaveChatState('success', '');
    } catch (err) {
      showSaveChatState('error', err.message || 'Save failed.');
    } finally {
      saveChatInProgress = false;
    }
  }

  function showSaveChatState(state, msg) {
    const btn = document.getElementById('tl-save-chat-btn');
    const label = document.getElementById('tl-save-chat-label');
    if (!btn || !label) return;
    if (state === 'loading') {
      btn.disabled = true;
      label.textContent = 'Saving…';
    } else if (state === 'success') {
      btn.disabled = false;
      label.textContent = '✓ Saved';
      btn.classList.add('tl-save-success');
      setTimeout(() => {
        label.textContent = 'Save Chat';
        btn.classList.remove('tl-save-success');
      }, 2500);
    } else if (state === 'error') {
      btn.disabled = false;
      label.textContent = msg || 'Error';
      btn.classList.add('tl-save-error');
      setTimeout(() => {
        label.textContent = 'Save Chat';
        btn.classList.remove('tl-save-error');
      }, 3000);
    }
  }

  // ── TL logo SVGs ──────────────────────────────────────────────────────
  const TL_SVG = '<svg class="tl-icon" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="4" width="12" height="4" fill="#6a9e88"/><rect x="7" y="4" width="4" height="20" fill="#6a9e88"/><rect x="16" y="10" width="4" height="14" fill="#6a9e88"/><rect x="16" y="20" width="8" height="4" fill="#6a9e88"/></svg>';
  const TL_SVG_SMALL = '<svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:18px;height:18px"><rect x="2" y="2" width="9" height="3" fill="#6a9e88"/><rect x="4.5" y="2" width="3" height="16" fill="#6a9e88"/><rect x="12" y="7" width="3" height="11" fill="#6a9e88"/><rect x="12" y="15" width="6" height="3" fill="#6a9e88"/></svg>';

  // ── Build DOM ─────────────────────────────────────────────────────────
  const root = document.createElement('div');
  root.id = 'tokenlens-root';
  const autoDisabled = adapter ? '' : 'disabled';
  const autoLabel = adapter ? 'Auto-detect prompt' : 'Auto-detect (unsupported here)';
  const injectBtnHTML = canInject
    ? '<button id="tl-inject-btn" title="Replace chat input with optimized prompt"><svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M2 8h10M8 4l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M2 4v8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg><span id="tl-inject-label">Inject</span></button>'
    : '';

  const __html =
    '<div id="tokenlens-panel">' +
      '<div id="tokenlens-header">' +
        '<div class="tl-logo">' + TL_SVG_SMALL + '<span>Token<span class="tl-dot">Lens</span></span></div>' +
        '<div class="tl-header-actions">' +
          '<button id="tl-theme-toggle" class="tl-icon-btn tl-theme-toggle" title="Toggle theme" aria-label="Toggle dark and light mode" type="button"><span id="tl-theme-icon">☾</span></button>' +
          '<button id="tl-help-btn" class="tl-icon-btn" title="Help and definitions" type="button">?</button>' +
          '<button id="tl-hotkeys-btn" class="tl-text-btn" title="View keyboard shortcuts" type="button">Hotkeys</button>' +
          '<button id="tokenlens-close" class="tl-icon-btn" title="Close" type="button">\u2715</button>' +
        '</div>' +
      '</div>' +
      '<div id="tl-tab-bar">' +
        '<button class="tl-tab active" id="tl-tab-analyze" type="button">Analyze</button>' +
        '<button class="tl-tab" id="tl-tab-power" type="button">Power User</button>' +
      '</div>' +
      '<div id="tl-health-compact" class="tl-health-pill ready">Ready · 0 context</div>' +
      '<div class="tl-panel-scroll">' +
        '<div id="tl-session-bar">' +
          '<div class="tl-session-item"><span class="tl-session-label">SESSION</span><span class="tl-session-value"><span id="tl-session-tokens">0</span> tokens</span></div>' +
          '<div class="tl-session-divider"></div>' +
          '<div class="tl-session-item"><span class="tl-session-label">MESSAGES</span><span class="tl-session-value" id="tl-session-msgs">0 msgs</span></div>' +
        '</div>' +
        '<div id="tokenlens-auth-gate">' +
          '<p><strong>Sign in to analyze</strong>TokenLens uses your account to track usage on your plan.</p>' +
          '<button id="tokenlens-signin-btn">SIGN IN TO TOKENLENS</button>' +
        '</div>' +
        '<div id="tokenlens-body">' +
          '<div id="tl-passive-insight" class="tl-passive-insight" style="display:none"></div>' +
          '<div id="tl-mode-bar">' +
            '<span class="tl-mode-label">MODE</span>' +
            '<button class="tl-mode-pill active" id="tl-mode-prompt" data-mode="prompt"><span class="tl-pill-dot"></span>Prompt</button>' +
            '<button class="tl-mode-pill" id="tl-mode-code" data-mode="code"><span class="tl-pill-dot"></span>Code</button>' +
            '<span id="tl-auto-mode-indicator">auto</span>' +
          '</div>' +
          '<textarea id="tokenlens-textarea" placeholder="Paste your prompt here, or enable auto-detect below\u2026" spellcheck="false"></textarea>' +
          '<div id="tokenlens-autodetect"><label><input type="checkbox" id="tokenlens-auto-checkbox" ' + autoDisabled + '>' + autoLabel + '</label></div>' +
          '<button id="tokenlens-analyze-btn">ANALYZE</button>' +
          '<div id="tokenlens-error"></div>' +
          '<div id="tl-higher-token-warning" style="display:none"><div class="tl-warning-icon">\u26a0\ufe0f</div><div class="tl-warning-body"><strong>Optimized prompt is longer</strong><p id="tl-warning-text"></p></div></div>' +
          '<div id="tokenlens-results">' +
            '<div id="tokenlens-optimized" class="tl-optimized-hero" style="display:none">' +
              '<div class="tl-optimized-header">' +
                '<span class="tl-optimized-label">OPTIMIZED PROMPT</span>' +
                '<div class="tl-optimized-actions">' + injectBtnHTML + '<button id="tl-copy-btn" title="Copy optimized prompt"><svg width="13" height="13" viewBox="0 0 16 16" fill="none"><rect x="5" y="5" width="9" height="9" rx="1.5" stroke="currentColor" stroke-width="1.5"/><path d="M11 5V3.5A1.5 1.5 0 009.5 2h-6A1.5 1.5 0 002 3.5v6A1.5 1.5 0 003.5 11H5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg><span id="tl-copy-label">Copy</span></button></div>' +
              '</div>' +
              '<div id="tokenlens-analysis" tabindex="-1"></div>' +
              '<div class="tl-optimized-hint">Review it, then use Ctrl + Enter to inject.</div>' +
            '</div>' +
            '<div class="tl-compare">' +
              '<div class="tl-compare-col"><div class="tl-compare-label">BEFORE</div><div class="tl-compare-tokens" id="tl-tokens-before">\u2014</div><div class="tl-compare-cost" id="tl-cost-before">\u2014</div><div class="tl-compare-words" id="tl-words-before">\u2014</div></div>' +
              '<div class="tl-compare-arrow"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8h10M9 4l4 4-4 4" stroke="#6a9e88" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><div class="tl-savings-badge" id="tl-savings-badge"></div></div>' +
              '<div class="tl-compare-col tl-compare-col--after"><div class="tl-compare-label">AFTER</div><div class="tl-compare-tokens" id="tl-tokens-after">\u2014</div><div class="tl-compare-cost" id="tl-cost-after">\u2014</div><div class="tl-compare-words" id="tl-words-after">\u2014</div></div>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div id="tl-power-pane" style="display:none">' +
          '<div class="tl-power-header"><div><span class="tl-power-kicker">POWER USER</span><h3>Chat usage breakdown</h3></div><button id="tl-power-refresh" type="button">Refresh</button></div>' +
          '<div id="tl-power-panel"></div>' +
        '</div>' +
      '</div>' +
      // ── FOOTER — Save Chat button lives here ──────────────────────────
      '<div id="tokenlens-footer">' +
        '<a href="https://tokenlens.live" target="_blank" rel="noopener">tokenlens.live</a>' +
        '<button id="tl-save-chat-btn" type="button" title="Save this chat session to your Blueprint Library">' +
          '<svg width="11" height="11" viewBox="0 0 16 16" fill="none"><path d="M8 2v8M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M2 11v2a1 1 0 001 1h10a1 1 0 001-1v-2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>' +
          '<span id="tl-save-chat-label">Save Chat</span>' +
        '</button>' +
      '</div>' +
    '</div>' +
    '<div id="tl-info-popover" class="tl-info-popover" style="display:none">' +
      '<div class="tl-info-card">' +
        '<div class="tl-info-head"><div><span id="tl-info-kicker" class="tl-info-kicker">HELP</span><h3 id="tl-info-title">Help & Definitions</h3></div><button id="tl-info-close" class="tl-icon-btn" type="button" title="Close">\u2715</button></div>' +
        '<div id="tl-info-body" class="tl-info-body"></div>' +
      '</div>' +
    '</div>' +
    '<button id="tokenlens-fab" title="TokenLens">' + TL_SVG + '<span id="tokenlens-badge"></span></button>';

  const __parsed = new DOMParser().parseFromString(__html, 'text/html');
  while (__parsed.body.firstChild) root.appendChild(__parsed.body.firstChild);
  document.body.appendChild(root);

  // ── Refs ──────────────────────────────────────────────────────────────
  const panel           = document.getElementById('tokenlens-panel');
  const fab             = document.getElementById('tokenlens-fab');
  const closeBtn        = document.getElementById('tokenlens-close');
  const themeToggle     = document.getElementById('tl-theme-toggle');
  const themeIcon       = document.getElementById('tl-theme-icon');
  const helpBtn         = document.getElementById('tl-help-btn');
  const hotkeysBtn      = document.getElementById('tl-hotkeys-btn');
  const infoPopover     = document.getElementById('tl-info-popover');
  const infoCloseBtn    = document.getElementById('tl-info-close');
  const infoKicker      = document.getElementById('tl-info-kicker');
  const infoTitle       = document.getElementById('tl-info-title');
  const infoBody        = document.getElementById('tl-info-body');
  const authGate        = document.getElementById('tokenlens-auth-gate');
  const body            = document.getElementById('tokenlens-body');
  const signinBtn       = document.getElementById('tokenlens-signin-btn');
  const textarea        = document.getElementById('tokenlens-textarea');
  const autoCheck       = document.getElementById('tokenlens-auto-checkbox');
  const analyzeBtn      = document.getElementById('tokenlens-analyze-btn');
  const results         = document.getElementById('tokenlens-results');
  const errorBox        = document.getElementById('tokenlens-error');
  const badge           = document.getElementById('tokenlens-badge');
  const copyBtn         = document.getElementById('tl-copy-btn');
  const copyLabel       = document.getElementById('tl-copy-label');
  const injectBtnEl     = document.getElementById('tl-inject-btn');
  const injectLabel     = document.getElementById('tl-inject-label');
  const warningEl       = document.getElementById('tl-higher-token-warning');
  const warningText     = document.getElementById('tl-warning-text');
  const modePromptBtn   = document.getElementById('tl-mode-prompt');
  const modeCodeBtn     = document.getElementById('tl-mode-code');
  const autoModeIndEl   = document.getElementById('tl-auto-mode-indicator');
  const analyzeTabBtn   = document.getElementById('tl-tab-analyze');
  const powerTabBtn     = document.getElementById('tl-tab-power');
  const powerPane       = document.getElementById('tl-power-pane');
  const powerRefreshBtn = document.getElementById('tl-power-refresh');
  const saveChatBtn     = document.getElementById('tl-save-chat-btn');

  // ── Theme ─────────────────────────────────────────────────────────────
  function applyTheme(theme) {
    const nextTheme = theme === 'light' ? 'light' : 'dark';
    root.setAttribute('data-theme', nextTheme);
    root.dataset.theme = nextTheme;
    if (themeIcon) themeIcon.textContent = nextTheme === 'light' ? '☀' : '☾';
    chrome.storage.local.set({ tokenlens_theme: nextTheme });
  }
  function loadTheme() { chrome.storage.local.get(['tokenlens_theme'], (data) => { applyTheme(data.tokenlens_theme || 'dark'); }); }
  if (themeToggle) themeToggle.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); const current = root.getAttribute('data-theme') || 'dark'; applyTheme(current === 'dark' ? 'light' : 'dark'); });
  loadTheme();

  // ── Mode ──────────────────────────────────────────────────────────────
  let currentMode = 'prompt';
  let autoModeActive = false;
  function setMode(mode, auto = false) {
    currentMode = mode; autoModeActive = auto;
    modePromptBtn.classList.toggle('active', mode === 'prompt');
    modeCodeBtn.classList.toggle('active', mode === 'code');
    autoModeIndEl.classList.toggle('visible', auto);
    textarea.placeholder = mode === 'code' ? 'Paste your code here, or enable auto-detect below\u2026' : 'Paste your prompt here, or enable auto-detect below\u2026';
    const optimizedLabel = document.querySelector('.tl-optimized-label');
    if (optimizedLabel) optimizedLabel.textContent = mode === 'code' ? 'OPTIMIZED CODE' : 'OPTIMIZED PROMPT';
  }
  modePromptBtn.addEventListener('click', () => setMode('prompt', false));
  modeCodeBtn.addEventListener('click', () => setMode('code', false));

  // ── Help / hotkeys ────────────────────────────────────────────────────
  const helpContent = '<div class="tl-help-grid"><div class="tl-definition"><strong>Context</strong><span>The running text a model may consider in a conversation. Long threads can become expensive and harder to manage.</span></div><div class="tl-definition"><strong>Token</strong><span>A small piece of text used for model processing. TokenLens estimates this from visible text.</span></div><div class="tl-definition"><strong>Conversation Health</strong><span>A simple status based on estimated growth, repetition, and visible message balance.</span></div><div class="tl-definition"><strong>Save Chat</strong><span>Captures the full visible conversation and saves it to your TokenLens Blueprint Library. From there you can generate a reusable blueprint with variable slots.</span></div><div class="tl-definition"><strong>Cache Candidate</strong><span>Repeated text that may be cache friendly. TokenLens does not claim actual provider cache hits from the page alone.</span></div><div class="tl-definition"><strong>Inject</strong><span>Replaces the supported chat input with the optimized result so you can keep working without copy and paste.</span></div></div>';
  const hotkeysContent = '<div class="tl-hotkey-list"><div class="tl-hotkey-row"><kbd>Ctrl/⌘</kbd><kbd>Shift</kbd><kbd>L</kbd><span>Open or close TokenLens</span></div><div class="tl-hotkey-row"><kbd>Ctrl/⌘</kbd><kbd>Enter</kbd><span>From chat: open and analyze. From TokenLens after results: inject optimized prompt.</span></div><div class="tl-hotkey-row"><kbd>Esc</kbd><span>Close Help or Hotkeys panel</span></div></div><p class="tl-info-note">More shortcuts can be added later, but keeping this list small avoids clutter.</p>';
  let activeInfoPanel = null;
  function showInfoPanel(type) {
    if (!infoPopover || !infoBody) return;
    if (activeInfoPanel === type && infoPopover.classList.contains('visible')) { hideInfoPanel(); return; }
    activeInfoPanel = type;
    const isHotkeys = type === 'hotkeys';
    infoKicker.textContent = isHotkeys ? 'SHORTCUTS' : 'HELP';
    infoTitle.textContent = isHotkeys ? 'Available Hotkeys' : 'Help & Definitions';
    infoBody.innerHTML = isHotkeys ? hotkeysContent : helpContent;
    infoPopover.style.display = 'block';
    infoPopover.classList.add('visible');
    helpBtn.classList.toggle('active', !isHotkeys);
    hotkeysBtn.classList.toggle('active', isHotkeys);
  }
  function hideInfoPanel() {
    activeInfoPanel = null;
    if (infoPopover) { infoPopover.classList.remove('visible'); infoPopover.style.display = 'none'; }
    helpBtn.classList.remove('active'); hotkeysBtn.classList.remove('active');
  }
  helpBtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); showInfoPanel('help'); });
  hotkeysBtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); showInfoPanel('hotkeys'); });
  infoCloseBtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); hideInfoPanel(); });
  infoPopover.addEventListener('click', (e) => { if (e.target === infoPopover) hideInfoPanel(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hideInfoPanel(); });

  // ── Auth ──────────────────────────────────────────────────────────────
  let authToken = null;
  let activeTab = 'analyze';
  function setActiveTab(tab) {
    activeTab = tab;
    analyzeTabBtn.classList.toggle('active', tab === 'analyze');
    powerTabBtn.classList.toggle('active', tab === 'power');
    if (tab === 'power') { authGate.classList.remove('visible'); body.style.display = 'none'; powerPane.style.display = 'block'; renderPowerUserPanel(); }
    else { powerPane.style.display = 'none'; updateAuthUI(); }
  }
  analyzeTabBtn.addEventListener('click', () => setActiveTab('analyze'));
  powerTabBtn.addEventListener('click', () => setActiveTab('power'));
  powerRefreshBtn.addEventListener('click', renderPowerUserPanel);
  function loadToken() { chrome.storage.local.get(['tokenlens_token'], (data) => { authToken = data.tokenlens_token ?? null; updateAuthUI(); }); }
  function refreshAuthToken() { return new Promise((resolve) => { chrome.storage.local.get(['tokenlens_token'], (data) => { authToken = data.tokenlens_token ?? null; updateAuthUI(); resolve(authToken); }); }); }
  chrome.storage.onChanged.addListener((changes) => { if (changes.tokenlens_token) { authToken = changes.tokenlens_token.newValue ?? null; updateAuthUI(); } });
  function updateAuthUI() {
    if (activeTab !== 'analyze') return;
    if (authToken) { authGate.classList.remove('visible'); body.style.display = 'block'; }
    else { authGate.classList.add('visible'); body.style.display = 'none'; }
    // Show/hide save button based on auth
    if (saveChatBtn) saveChatBtn.style.display = authToken ? 'inline-flex' : 'none';
  }
  signinBtn.addEventListener('click', () => window.open('https://tokenlens.live', '_blank'));

  // ── Save Chat button wire-up ──────────────────────────────────────────
  if (saveChatBtn) {
    saveChatBtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); saveChatAsBlueprint(); });
  }

  // ── Panel open / close ────────────────────────────────────────────────
  let panelOpen = false;
  function openPanel() { loadToken(); panel.classList.add('open'); panelOpen = true; renderPowerUserPanel(); if (authToken && autoCheck.checked) syncPrompt(); }
  function closePanel() { panel.classList.remove('open'); panelOpen = false; }
  fab.addEventListener('click', () => panelOpen ? closePanel() : openPanel());
  closeBtn.addEventListener('click', closePanel);
  document.addEventListener('click', (e) => { if (panelOpen && !root.contains(e.target)) closePanel(); });
  document.addEventListener('keydown', (e) => {
    const key = (e.key || '').toLowerCase();
    if (key === 'escape' && infoPopover && infoPopover.style.display !== 'none') { hideInfoPanel(); return; }
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && key === 'l') { e.preventDefault(); panelOpen ? closePanel() : openPanel(); }
  });

  // ── Auto-detect + code sniffing ───────────────────────────────────────
  function syncPrompt() {
    if (!adapter) return;
    const text = adapter.getPrompt().trim();
    if (text) { textarea.value = text; autoDetectMode(text); }
    updateBadge(text);
  }
  function autoDetectMode(text) {
    const isCode = detectCode(text);
    const newMode = isCode ? 'code' : 'prompt';
    if (newMode !== currentMode) setMode(newMode, true);
  }
  const debouncedSync = debounce(() => { if (!autoCheck.checked || !panelOpen) return; syncPrompt(); }, 600);
  if (adapter) { document.addEventListener('input', debouncedSync, true); document.addEventListener('keyup', debouncedSync, true); }
  autoCheck.addEventListener('change', () => { if (autoCheck.checked) syncPrompt(); });

  let lastAnalyzedPrompt = '';
  let optimizedText = '';
  textarea.addEventListener('input', () => {
    const currentText = textarea.value.trim();
    if (lastAnalyzedPrompt && currentText !== lastAnalyzedPrompt) { optimizedText = ''; lastAnalyzedPrompt = ''; }
    updateBadge(textarea.value); autoDetectMode(textarea.value); updateSessionUI();
  });

  // ── Badge ─────────────────────────────────────────────────────────────
  function updateBadge(text) {
    if (!text?.trim()) { badge.classList.remove('visible'); return; }
    badge.textContent = fmt(Math.ceil(text.length / 4));
    badge.classList.add('visible');
  }
  function fmt(n) { return n >= 1000 ? (n / 1000).toFixed(1) + 'k' : String(n); }

  // ── Copy ──────────────────────────────────────────────────────────────
  copyBtn.addEventListener('click', () => {
    if (!optimizedText) return;
    navigator.clipboard.writeText(optimizedText).then(() => {
      copyLabel.textContent = 'Copied!'; copyBtn.classList.add('copied');
      setTimeout(() => { copyLabel.textContent = 'Copy'; copyBtn.classList.remove('copied'); }, 2000);
    }).catch(() => {
      const ta = document.createElement('textarea'); ta.value = optimizedText; ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
      copyLabel.textContent = 'Copied!'; setTimeout(() => { copyLabel.textContent = 'Copy'; }, 2000);
    });
  });

  // ── Inject ────────────────────────────────────────────────────────────
  function injectOptimizedPrompt({ closeAfter = false } = {}) {
    if (!optimizedText || !adapter || !canInject) return false;
    const ok = adapter.setPrompt(optimizedText);
    if (injectLabel && injectBtnEl) {
      injectLabel.textContent = ok ? 'Injected!' : 'Failed';
      injectBtnEl.classList.toggle('injected', ok);
      setTimeout(() => { injectLabel.textContent = 'Inject'; injectBtnEl.classList.remove('injected'); }, 2000);
    }
    if (ok && closeAfter) closePanel();
    return ok;
  }
  if (injectBtnEl) injectBtnEl.addEventListener('click', () => injectOptimizedPrompt());
  const optimizedCard = document.getElementById('tokenlens-optimized');
  if (optimizedCard) optimizedCard.addEventListener('dblclick', (e) => { e.preventDefault(); injectOptimizedPrompt(); });

  // ── API call ──────────────────────────────────────────────────────────
  let analyzeShortcutLocked = false;
  async function safeAnalyze() {
    if (analyzeShortcutLocked || analyzeBtn.disabled) return;
    analyzeShortcutLocked = true;
    try { await analyze(); } finally { window.setTimeout(() => { analyzeShortcutLocked = false; }, 500); }
  }
  async function analyze() {
    if (!authToken) { authGate.classList.add('visible'); body.style.display = 'none'; return; }
    const prompt = textarea.value.trim();
    if (!prompt) { showError('Please enter a prompt first.'); return; }
    setLoading(true); hideError(); results.classList.remove('visible'); warningEl.style.display = 'none';
    try {
      const res = await fetch('https://tokenlens.live/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + authToken },
        body: JSON.stringify({ prompt, level: currentMode === 'code' ? 'deep' : 'balanced' })
      });
      if (res.status === 401) { chrome.storage.local.remove(['tokenlens_token','tokenlens_token_at']); authToken = null; updateAuthUI(); showError('Session expired. Please sign in again at tokenlens.live.'); return; }
      if (!res.ok) { const data = await res.json().catch(() => ({})); throw new Error(data.error || 'Server error: ' + res.status); }
      const data = await res.json();
      renderResults(data.results ?? data, prompt);
    } catch (err) { showError(err.message || 'Could not reach tokenlens.live.'); }
    finally { setLoading(false); }
  }
  analyzeBtn.addEventListener('click', safeAnalyze);

  async function analyzeFromShortcut() {
    if (!panelOpen) openPanel();
    setActiveTab('analyze'); hideInfoPanel();
    const active = document.activeElement;
    const insideWidget = !!(active && root.contains(active));
    const detectedText = adapter ? (adapter.getPrompt() || '').trim() : '';
    const widgetText = textarea.value.trim();
    if (detectedText && (!insideWidget || !widgetText || autoCheck.checked)) {
      textarea.value = detectedText; autoDetectMode(detectedText); updateBadge(detectedText); updateSessionUI();
    }
    await refreshAuthToken();
    if (!textarea.value.trim()) { showError(adapter ? 'No prompt detected. Type in the chat input or paste text into TokenLens first.' : 'Paste text into TokenLens first. Auto detect is not supported on this site.'); textarea.focus(); return; }
    await safeAnalyze();
  }

  document.addEventListener('keydown', (e) => {
    const isPrimaryShortcut = (e.ctrlKey || e.metaKey) && !e.shiftKey && e.key === 'Enter';
    if (!isPrimaryShortcut) return;
    const active = document.activeElement;
    const insideWidget = !!(active && root.contains(active));
    e.preventDefault(); e.stopImmediatePropagation();
    const currentWidgetText = textarea.value.trim();
    const optimizedIsCurrent = !!optimizedText && (!lastAnalyzedPrompt || currentWidgetText === lastAnalyzedPrompt);
    if (panelOpen && optimizedIsCurrent && canInject) { injectOptimizedPrompt({ closeAfter: true }); return; }
    analyzeFromShortcut();
  }, true);

  // ── Render results ────────────────────────────────────────────────────
  function renderResults(data, prompt) {
    lastAnalyzedPrompt = (prompt || '').trim();
    const beforeTokens = data.estimated_tokens ?? data.token_count ?? data.tokens ?? null;
    const beforeCost   = data.cost_estimate_usd ?? data.estimated_cost ?? data.cost ?? null;
    const afterTokens  = data.efficient_tokens ?? null;
    const savings      = data.savings_percent ?? null;
    const optimized    = data.efficient_prompt ?? data.analysis ?? '';
    const beforeWords  = countWords(prompt);
    const afterWords   = optimized ? countWords(optimized) : null;
    let afterCost = null;
    if (beforeCost != null && beforeTokens && afterTokens) afterCost = beforeCost * (afterTokens / beforeTokens);
    const isHigher = afterTokens != null && beforeTokens != null && afterTokens > beforeTokens;
    if (isHigher) {
      const diff = afterTokens - beforeTokens;
      const pct  = Math.round((diff / beforeTokens) * 100);
      warningText.textContent = 'The optimized version is ' + diff + ' tokens (' + pct + '%) longer than the original. This can happen when adding missing context, clarifying ambiguous instructions, or specifying output format \u2014 all of which reduce back-and-forth with the model, saving tokens across the full conversation. A slightly longer prompt that gets the right answer first try is almost always cheaper overall.';
      warningEl.style.display = 'flex';
    } else { warningEl.style.display = 'none'; }
    document.getElementById('tl-tokens-before').textContent = beforeTokens != null ? beforeTokens.toLocaleString() + ' tokens' : '\u2014';
    document.getElementById('tl-cost-before').textContent   = beforeCost != null ? formatCost(beforeCost) : '\u2014';
    document.getElementById('tl-words-before').textContent  = beforeWords + ' words';
    document.getElementById('tl-tokens-after').textContent  = afterTokens != null ? afterTokens.toLocaleString() + ' tokens' : '\u2014';
    document.getElementById('tl-cost-after').textContent    = afterCost != null ? formatCost(afterCost) : '\u2014';
    document.getElementById('tl-words-after').textContent   = afterWords != null ? afterWords + ' words' : '\u2014';
    const savingsBadge = document.getElementById('tl-savings-badge');
    if (savings != null) { savingsBadge.textContent = isHigher ? '+' + Math.abs(savings) + '%' : '\u2212' + savings + '%'; savingsBadge.classList.toggle('higher', isHigher); savingsBadge.style.display = 'block'; }
    else savingsBadge.style.display = 'none';
    const optimizedEl = document.getElementById('tokenlens-optimized');
    const analysisEl  = document.getElementById('tokenlens-analysis');
    if (optimized && optimized !== prompt) {
      optimizedText = optimized; analysisEl.textContent = optimized; optimizedEl.style.display = 'block';
    } else { optimizedText = ''; optimizedEl.style.display = 'none'; }
    if (beforeTokens != null) { badge.textContent = fmt(beforeTokens); badge.classList.add('visible'); }
    results.classList.add('visible');
    if (optimizedEl && optimizedText) {
      optimizedEl.classList.remove('tl-hero-ready');
      requestAnimationFrame(() => optimizedEl.classList.add('tl-hero-ready'));
      const scrollRoot = document.querySelector('#tokenlens-panel .tl-panel-scroll');
      if (scrollRoot) scrollRoot.scrollTo({ top: results.offsetTop - 8, behavior: 'smooth' });
      if (analysisEl) { analysisEl.setAttribute('tabindex', '-1'); setTimeout(() => analysisEl.focus({ preventScroll: true }), 120); }
      if (injectBtnEl) { injectBtnEl.classList.add('tl-primary-pulse'); setTimeout(() => injectBtnEl.classList.remove('tl-primary-pulse'), 1400); }
    }
  }

  function formatCost(cost) {
    if (typeof cost === 'string') return cost;
    if (cost === 0) return '$0.00000';
    if (cost < 0.00001) return '<$0.00001';
    if (cost < 0.001)   return '$' + cost.toFixed(5);
    return '$' + cost.toFixed(4);
  }
  function countWords(text) { return text.trim().split(/\s+/).filter(Boolean).length; }

  // ── UI helpers ────────────────────────────────────────────────────────
  function setLoading(on) {
    analyzeBtn.disabled = on;
    while (analyzeBtn.firstChild) analyzeBtn.removeChild(analyzeBtn.firstChild);
    if (on) { const sp = document.createElement('span'); sp.className = 'tl-spinner'; analyzeBtn.appendChild(sp); analyzeBtn.appendChild(document.createTextNode('ANALYZING…')); }
    else analyzeBtn.textContent = 'ANALYZE';
  }
  function showError(msg) { errorBox.textContent = msg; errorBox.classList.add('visible'); }
  function hideError() { errorBox.classList.remove('visible'); }

  // ── Init ──────────────────────────────────────────────────────────────
  loadToken(); loadMemorySnippets(); updateSessionUI(); startSessionTracker();
})();
